<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Manager extends CI_Controller
{
    public function dashboard()
    {
        $this->load->view('manager/dashboard');
    }
}
