<?php
defined('BASEPATH') or exit('No direct script access allowed');

class admin extends CI_Controller
{
    public function dashboard()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }

        if ($this->session->userdata('role') != 'admin') {
            show_error('Akses ditolak: Anda bukan admin', 403, 'Akses Ditolak');
        }

        $this->load->view('admin/dashboard');
    }
}
