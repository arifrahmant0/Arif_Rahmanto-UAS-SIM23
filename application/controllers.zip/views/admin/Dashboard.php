<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <h1 class="m-0">Dashboard Admin</h1>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="alert alert-info">Selamat datang, <strong><?= $this->session->userdata('username'); ?></strong>! Anda login sebagai <strong>Admin</strong>.</div>
            <p>Gunakan menu di samping untuk mengelola data user, produk, pesanan, dan laporan.</p>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>