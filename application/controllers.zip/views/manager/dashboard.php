<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <h1 class="m-0">Dashboard Manager</h1>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="alert alert-warning">Selamat datang, <strong><?= $this->session->userdata('username'); ?></strong>! Anda login sebagai <strong>Manager</strong>.</div>
            <p>Anda dapat memantau penjualan dan performa tim dari sini.</p>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>