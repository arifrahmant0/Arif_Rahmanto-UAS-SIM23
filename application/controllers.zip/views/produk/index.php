<div class="card">
    <div class="card-header">
        <a href="<?php echo base_url('admin/produk/tambah'); ?>" class="btn btn-primary">Tambah Produk</a>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Dibuat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produk as $i => $p) : ?>
                    <tr>
                        <td><?php echo $i + 1; ?></td>
                        <td><?php echo $p->kode_produk; ?></td>
                        <td><?php echo $p->nama_produk; ?></td>
                        <td>Rp<?php echo number_format($p->harga); ?></td>
                        <td><?php echo $p->stok; ?></td>
                        <td><?php echo date('d-m-Y H:i', strtotime($p->created_at)); ?></td>
                        <td>
                            <a href="<?php echo base_url('admin/produk/edit/' . $p->id); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="<?php echo base_url('admin/produk/hapus/' . $p->id); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>