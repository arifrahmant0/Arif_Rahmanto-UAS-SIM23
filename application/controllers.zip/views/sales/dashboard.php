<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <h1 class="m-0">Dashboard Sales</h1>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="alert alert-success">Halo, <strong><?= $this->session->userdata('username'); ?></strong>! Anda login sebagai <strong>Sales</strong>.</div>
            <p>Gunakan fitur ini untuk mencatat pesanan dan melihat status order pelanggan.</p>
        </div>
    </div>
</div>

<?php $this->load->view('templates/footer'); ?>