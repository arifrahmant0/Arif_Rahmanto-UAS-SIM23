<ul class="nav nav-pills nav-sidebar flex-column" role="menu">
    <li class="nav-item">
        <a href="<?= base_url('manager/dashboard') ?>" class="nav-link">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="<?= base_url('manager/laporan') ?>" class="nav-link">
            <i class="nav-icon fas fa-chart-line"></i>
            <p>Laporan Penjualan</p>
        </a>
    </li>
</ul>