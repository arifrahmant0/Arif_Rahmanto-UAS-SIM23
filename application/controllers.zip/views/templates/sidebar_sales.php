<ul class="nav nav-pills nav-sidebar flex-column" role="menu">
    <li class="nav-item">
        <a href="<?= base_url('sales/dashboard') ?>" class="nav-link">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="<?= base_url('sales/order') ?>" class="nav-link">
            <i class="nav-icon fas fa-plus-circle"></i>
            <p>Buat Sales Order</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="<?= base_url('sales/history') ?>" class="nav-link">
            <i class="nav-icon fas fa-history"></i>
            <p>Riwayat Order Saya</p>
        </a>
    </li>
</ul>