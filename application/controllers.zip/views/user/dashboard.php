<div class="content-wrapper">
    <section class="content-header">
        <h1>Dashboard User</h1>
    </section>
    <section class="content">
        <p>Selamat datang, <?= $this->session->userdata('username'); ?>! Anda login sebagai <b>User</b>.</p>
    </section>
</div>